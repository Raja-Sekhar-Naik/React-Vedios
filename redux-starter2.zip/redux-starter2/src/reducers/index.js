import { combineReducers } from "redux";
import counterReducer from "./counterReducer";

const rootReducer = combineReducers({
  counterReducer,
});
/**
 * combineReducers accepts an object full of reducer functions as its argument
 * and returns a function that calls each reducer whenever an action is dispatched.
 * The result from each reducer are all combined together into a single object
 * as the final result.
 */

export default rootReducer;
