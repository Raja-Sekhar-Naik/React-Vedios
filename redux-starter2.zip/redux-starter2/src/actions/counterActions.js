export const Increment = (step) => {
  //return Action object
  return {
    type: "INCREMENT", // type of Action
    payload: {
      // data passed as part of Action
      data: step,
    },
  };
};

export const Decrement = (step) => {
  //return Action object
  return {
    type: "DECREMENT", // type of Action
    payload: {
      // data passed as part of Action
      data: step,
    },
  };
};
