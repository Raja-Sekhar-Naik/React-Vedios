import React from "react";
import UseEffect1 from "./UseEffect1";
import UseState1 from "./UseState1";

export default class HooksWrapper extends React.Component {
  render() {
    return (
      <React.Fragment>
        <h2>React Hooks</h2>
        <article className="m-1 border border-secondary rounded">
          {/*<UseState1 /> */}
          <UseEffect1 />
        </article>
      </React.Fragment>
    );
  }
}
