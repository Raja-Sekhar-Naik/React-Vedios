import React, { Component, memo } from "react";

class LCTester extends Component {
  constructor(props) {
    super(props);
    this.state = { favoritecolor: "" };
  }

  // event handlers
  changeToGreen = () => {
    this.setState({ favoritecolor: "Green" });
  };

  changeToGrey = () => {
    this.setState({ favoritecolor: "Grey" });
  };

  changeToBlue = () => {
    this.setState({ favoritecolor: "Blue" });
  };

  // set state here
  componentDidMount() {
    this.setState({ favoritecolor: this.props.favcol });
  }

  // check if component should be re-rendered
  shouldComponentUpdate(newProps, newState) {
    if (newState.favoritecolor === "Blue") return false;
    // prevent updation for state change to "Blue"
    else return true;
  }

  getSnapshotBeforeUpdate(prevProps, prevState) {
    console.log(
      "Just before commiting DOM update. Old value: " + prevState.favoritecolor
    );
    return null;
  }

  // must be used if getSnapshotBeforeUpdate(...) is used
  componentDidUpdate(prevProps, prevState, snapshot) {
    console.log("Component successfully updated");
  }

  render() {
    return (
      <React.Fragment>
        <p>Favorite Color (child) : {this.state.favoritecolor}</p>
        <button
          type="button"
          className="m-1 btn btn-outline-success"
          onClick={this.changeToGreen}
        >
          Green
        </button>
        <button
          type="button"
          className="m-1 btn btn-outline-secondary"
          onClick={this.changeToGrey}
        >
          Grey
        </button>
        <button
          type="button"
          className="m-1 btn btn-outline-primary"
          onClick={this.changeToBlue}
        >
          Blue
        </button>
      </React.Fragment>
    );
  }
}

export default memo(LCTester);
