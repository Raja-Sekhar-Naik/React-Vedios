import { connect } from "react-redux";
import { Decrement, Increment } from "./actions/actions";
import Counter from "./components/Counter";

// get count from state in Store and map it to a property
var mapStateToProps = (state) => {
  return {
    count: state.count,
  };
};

// map methods used by Child to actions to be dispatched
var mapDispatchToProps = (dispatch) => {
  return {
    onIncrement: (step) => {
      dispatch(Increment(step));
    },
    onDecrement: (step) => {
      dispatch(Decrement(step));
    },
  };
};

var App = connect(mapStateToProps, mapDispatchToProps)(Counter);
export default App;

/* import React from "react";
import Counter from "./components/Counter";

export default class App extends React.Component {
  constructor() {
    super();
    this.state = {
      count: 0,
    };
  }

  Increment = (step) => {
    this.setState({ count: this.state.count + step });
  };

  Decrement = (step) => {
    this.setState({ count: this.state.count - step });
  };

  render() {
    return (
      <React.Fragment>
        <Counter
          count={this.state.count}
          onIncrement={this.Increment}
          onDecrement={this.Decrement}
        />
      </React.Fragment>
    );
  }
}
 */
