export function Increment(step) {
  //describing Action INCREMENT
  return {
    type: "INCREMENT", // type of Action
    payload: {
      // data passed as part of Action
      data: step,
    },
  };
}

export function Decrement(step) {
  //describing Action DECREMENT
  return {
    type: "DECREMENT", // type of Action
    payload: {
      // data passed as part of Action
      data: step,
    },
  };
}
