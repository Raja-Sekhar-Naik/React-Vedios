import React from "react";

export default class Counter extends React.Component {
  constructor(props) {
    super(props);
  }
  render() {
    return (
      <React.Fragment>
        <header className="m-1 border border-dark rounded">
          <h1 className="text-center text-primary">Redux Demo</h1>
        </header>
        <section className="m-1 border border-dark rounded">
          <p className="m-2 lead">Value from prop: {this.props.count}</p>
          <button
            className="btn btn-success btn-sm m-2"
            onClick={() => {
              this.props.onIncrement(1);
            }}
          >
            Increment
          </button>
          <button
            className="btn btn-warning btn-sm"
            onClick={() => {
              this.props.onDecrement(1);
            }}
          >
            Decrement
          </button>
        </section>
      </React.Fragment>
    );
  }
}
