const initialState = { count: 0 }; // state is immutable, hence initialised as const

var reducer = (state = initialState, action) => {
  //check whether the reducer cares about this action
  switch (action.type) {
    // if yes
    case "INCREMENT":
      //make a copy of the state
      return Object.assign(
        {},
        state,
        //update the copy with new values
        { count: state.count + action.payload.data }
      );

    // update copy of store for INCREMENT
    case "DECREMENT":
      return Object.assign({}, state, {
        count: state.count - action.payload.data,
      });

    //otherwise, return the existing state unchanged
    default:
      return state;
  }
};

export default reducer;
