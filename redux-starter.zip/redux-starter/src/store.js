import { createStore } from "redux";
import reducer from "./reducers/reducer";

// create store based on initilization and
//dispatch actions defined in reducer
var store = createStore(
  reducer,
  window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__()
);

export default store;
